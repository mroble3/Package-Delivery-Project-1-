class Truck:


    def __init__(self, truckid, packagelist, starttime):
        self.truckid = truckid
        self.packagelist = packagelist
        self.starttime = starttime
